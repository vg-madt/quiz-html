

var state = {questions: [], answers: []};
var name;

function fetchHtmlData(){
  
  var disp = document.getElementById('question');
  var x = document.getElementById('click');
  x.play();

  var sw1 = document.getElementById("switch1");
  sw1.style.display = "none";
  var sw2 = document.getElementById("questions");
  sw2.style.display = "block";

fetch("http://localhost:8080/topic/html/get").then(res => res.json()).then(questions => {
  console.log("Response from network",questions);
    var i = 0;
    var allQuestions = "";
    state.questions = questions;
    questions.forEach(item =>{
      console.log("Object -->",item);
      var displayStyle = i === 0 ? "block" : "none";
      var question = "<div id=\"question" + i + "\" style=\"display: " + displayStyle + ";\">" +
      "<p id=\"question\">" + item.question + "</p>" +
        "<ul>" +
          "<li><p id=\"" + i + "0\" class=\"answer\" onclick=\"answerSelected("+i+",0)\">" + item.choices[0] + "</p></li>" +
          "<li><p id=\"" + i + "1\" class=\"answer\" onclick=\"answerSelected("+i+",1)\">" + item.choices[1] + "</p></li>" +
          "<li><p id=\"" + i + "2\" class=\"answer\" onclick=\"answerSelected("+i+",2)\">" + item.choices[2] + "</p></li>" +
          "<li><p id=\"" + i + "3\" class=\"answer\" onclick=\"answerSelected("+i+",3)\">" + item.choices[3] + "</p></li>" +
        "</ul>" + 
        getButton(i, questions.length) +
      "</div>";
      i++;
      allQuestions += question;
      console.log("displaying question no: ",i);
    });
    document.getElementById("questions").innerHTML = allQuestions;
});

}

function getButton(index, length) {
  console.log("Index: " + index + "; Length: " + length);

  let button = "<span style=\"display:inline-flex;\">";
  if (index > 0) {
    button += "<a class=\"btn\" onclick=\"displayPrevious('" + (index) + "')\">Previous</a>";
  }
  button += "</span><span style=\"display:inline-flex;\">";
  if (index === length - 1) {
    button += "<a class=\"btn\" onclick=\"saveAnswer()\">Finish</a>";
  } else {
    button += "<a class=\"btn\" onclick=\"displayNext('" + (index + 1) + "')\">Next</a>";
  }
  button +="</span>";
  console.log("Button: " + button);
  return button;
}


function saveAnswer() {
  console.log("State --->",state);
  var header = new Headers();
  header.append("Content-Type", "application/json");
  fetch('http://localhost:8080/topic/html/student/'+name+'/answer', {
    method: 'post',
    headers: header,
    body: JSON.stringify(state)
  }).then(res => {
    console.log("Invoking response...", res);
    try {
      return res.json();
    } catch (err) {
      return err;
    }
    console.log("Parsed response...");
  }).then(data => {
    console.log("Answer response: ", data);
    let sw1 = document.getElementById("questions");
    sw1.style.display = "none";
    let sw2 = document.getElementById("answer");
    sw2.style.display = "block";
    let answerHtml = "";
    answerHtml += "<span>" + data.message + "</span>";
    answerHtml += "<a class=\"btn\" onclick=\"showLeaderBoard()\"/>";
    document.getElementById().innerHTML = answerHtml;
  });
}

function showLeaderBoard() {
  fetch('http://localhost:8080/topic/html/result').then(res => res.json()).then(json => {
    console.log("Result -->", json);
  });
}

function displayNext(index) {
  document.getElementById("question" + (index - 1)).style.display = "none";
  document.getElementById("question" + index).style.display = "block";
}

function displayPrevious(index) {
  if (index === 0) {
    return;
  }
  document.getElementById("question" + (index - 1)).style.display = "block";
  document.getElementById("question" + index).style.display = "none";
}



function answerSelected(qIndex, aIndex){
  var x = document.getElementById(qIndex+""+aIndex);
  x.style.background = '#2b7a78';
  state.answers[qIndex] = {answer: state.questions[qIndex].choices[aIndex]};
  console.log("Selected q",qIndex);
  for(var i =0;i<4;i++){
    if(i!=aIndex){
      document.getElementById(qIndex+""+i).style.background = '#feffff'
      
    }
  }
  
}

function validate(){
  console.log("validate");
  name = document.getElementById("name").value;
  if(x < 1){
    alert("Please enter your Name");
    var y = document.getElementById("start");
    y.href="";
  }
  
}

