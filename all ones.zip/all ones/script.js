

var state = {questions: [], answers: []};
var name;
var flagForChoice = 0;
var currentTest;
var allScores;
var scoreSubject;
var isTestStarted = false;
var timerCompleted = false;

function fetchData(value){
  currentTest = value;
  var disp = document.getElementById('question');
  var x = document.getElementById('click');
  x.play();

  document.getElementById("answer").style.display = "none";
  var sw1 = document.getElementById("switch1");
  sw1.style.display = "none";
  var sw2 = document.getElementById("questions");
  sw2.style.display = "block";

fetch("http://localhost:8080/topic/"+value+"/get").then(res => res.json()).then(questions => {
  console.log("Response from network",questions);
    var i = 0;
    callTimer();
    var allQuestions = "";
    document.getElementById("qNo").style.display = "block";
    
    state.questions = questions;
    questions.forEach(item =>{
      console.log("Object -->",item);
      var displayStyle = i === 0 ? "block" : "none";
      var question = "<div id=\"question" + i + "\" style=\"display: " + displayStyle + ";\">" +
      "<p id=\"question\">" + item.question + "</p>" +
        "<ul>" +
          "<li><p id=\"" + i + "0\" class=\"answer\" onclick=\"answerSelected("+i+",0)\">" + item.choices[0] + "</p></li>" +
          "<li><p id=\"" + i + "1\" class=\"answer\" onclick=\"answerSelected("+i+",1)\">" + item.choices[1] + "</p></li>" +
          "<li><p id=\"" + i + "2\" class=\"answer\" onclick=\"answerSelected("+i+",2)\">" + item.choices[2] + "</p></li>" +
          "<li><p id=\"" + i + "3\" class=\"answer\" onclick=\"answerSelected("+i+",3)\">" + item.choices[3] + "</p></li>" +
        "</ul>" + 
        getButton(i, questions.length, value) +
      "</div>";
      i++;
      allQuestions += question;

      
      console.log("displaying question no: ",i);
    });
    document.getElementById("questions").innerHTML = allQuestions;
    console.log("displays question ", i)
    if(timerCompleted === true){
      console.log("saving answers");
      saveAnswer(value);
    }
});

}

function callTimer(){
 
  var minutes = 1;
  let time = minutes * 60;
  var seconds;
  var timer = document.getElementById('timer');
  timer.style.display="inline-flex";
  
  var interval = setInterval(updateCounter,1000);
  
  function updateCounter(){
    if(time!==0){
    
    var minutes = Math.floor(time/60);
    seconds = time%60;
     seconds = seconds < 10?'0' + seconds : seconds;
     
     timer.innerHTML = minutes+":"+seconds;
      time--;
    }
      else{
        timer.innerHTML = "0:00";
        clearInterval(interval);
        timerCompleted = true;
        console.log("timer is completed")

      }
        
     
  }
}

function getButton(index, length, value) {
  console.log("Index: " + index + "; Length: " + length);

  let button = "<table><tr><span style=\"display:inline-flex;\">";
  if (index > 0) {
    button += "<td><a class=\"btn\" onclick=\"displayPrevious('" + (index) + "')\">Previous</a></td>";
  }
  button += "<td></span><span style=\"display:inline-flex;\">";
  if (index === length - 1) {
    console.log("Button finish function invoked");
    button += "<a class=\"btn\" onclick=\"saveAnswer('"+value+"')\">Finish</a></td>";
  } else {
    button += "<a class=\"btn\" onclick=\"displayNext('" + (index + 1) + "')\">Next</a></td>";
  }
  button +="</span></tr></table>";
  console.log("Button: " + button);
  return button;
}


function saveAnswer(value) {
  console.log("State --->",state);
  var header = new Headers();
  header.append("Content-Type", "application/json");
  fetch('http://localhost:8080/topic/'+value+'/student/'+name+'/answer', {
    method: 'post',
    headers: header,
    body: JSON.stringify(state)
  }).then(res => {
    console.log("Invoking response...", res);
    try {
      return res.json();
    } catch (err) {
      return err;
    }
    console.log("Parsed response...");
  }).then(data => {
    console.log("Answer response: ", data);
    let sw1 = document.getElementById("questions");
    sw1.style.display = "none";
    let sw2 = document.getElementById("answer");
    sw2.style.display = "block";
    
    let finalAnswerString = displayResult(data, value);
    
    document.getElementById("answer").innerHTML = finalAnswerString;
    
  });
}

function displayResult(data, value){
  let answerHtml = "<br><br><span style=\"text-align:Center;\">";
  let subject = value;
  document.getElementById("qNo").style.display = "none";
  document.getElementById("timer").style.display = "none";

  if((data.score*10) > 8){
    answerHtml += "<h2> Congratulations! " + data.student + " You have successfully passed the test. You are now certified in "+subject+"</h2>";
    answerHtml += "<div>Your score is: " + data.score * 10 + "</div>";
    answerHtml += "<div>Your Test Date: " + data.attemptedOn + "</div></span>";
    answerHtml += "<table><tr><td><a class=\"btn\" href=\"index.html\">Exit</a></td>";
    answerHtml += "<td><a class=\"btn\" href=\"startActivity.html\">Take Another Test</a></td></tr></table>";
  }
  else{
    answerHtml += "<h2> Sorry! " + data.student + " You have failed the test. Please try again later</h2>";
    answerHtml += "<div>Your score is: " + data.score * 10 + "</div>";
    answerHtml += "<div>Your Test Date: " + data.attemptedOn + "</div></span>";
    answerHtml += "<table><tr><td><a class=\"btn\" onclick=\"fetchData('"+currentTest+"')\">Retry</a></td>";
    answerHtml += "<td><a class=\"btn\" href=\"startActivity.html\">Take Another Test</a></td></tr></table>";
    document.getElementById("qNo").innerHTML="Question: 1/10";

  }
  return answerHtml;
}

function showAllScores(localVal) {
  
  localStorage.setItem("localVal", localVal);
  
  
  
}

function displayAllScores(){
  document.getElementById("score").play();
  document.getElementById("score").muted= false;
  console.log("Playing music");

  
  scoreSubject = localStorage.getItem("localVal");
  
  fetch('http://localhost:8080/topic/'+scoreSubject+'/result').then(res => res.json()).then(json => {
    console.log("Result -->", json);
    
    json.scores.forEach(s =>{
    console.log("Object -->",s);
    console.log("Displays the name ",s.student);
    
    if((s.score* 10)>8){
      var stu = s.student.replace(/^\s+/g,'');
  var x = stu +'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+(s.score*10);
  var y = document.createElement("LI");
  var t = document.createTextNode(x);
  y.appendChild(t);
  document.getElementById("list").appendChild(y)
    }
  });

});      
}

function displayNext(index) {


  //alert if option is not chosen
  if(flagForChoice!==1){
    alert("Please choose an option");
  }else{
  document.getElementById("question" + (index - 1)).style.display = "none";
  document.getElementById("question" + index).style.display = "block";
  document.getElementById("qNo").innerHTML="Question: "+(++index)+"/10";
  flagForChoice = 0;
  }
}

function displayPrevious(index) {
  if (index === 0) {
    return;
  }
  document.getElementById("question" + (index - 1)).style.display = "block";
  document.getElementById("question" + index).style.display = "none";
  document.getElementById("qNo").innerHTML="Question: "+(index--)+"/10";
  flagForChoice = 1;
}



function answerSelected(qIndex, aIndex){
  flagForChoice = 1;
  var x = document.getElementById(qIndex+""+aIndex);
  x.style.background = '#2b7a78';
  state.answers[qIndex] = {answer: state.questions[qIndex].choices[aIndex]};
  console.log("Selected q",qIndex);
  for(var i =0;i<4;i++){
    if(i!=aIndex){
      document.getElementById(qIndex+""+i).style.background = '#feffff'
      
    }
  }
  
}

function validate(){
  console.log("validate");
  name = document.getElementById("name").value;
  if(name < 1){
    alert("Please enter your Name");
    var y = document.getElementById("start");
    y.href="";
  }
  
}



